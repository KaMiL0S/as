
$(function(){
    $('#HMenu').on('click', function(){
        $('.menu-trigger').trigger('click');
        setTimeout(function(){ $('#M_hombre').trigger('click');;$('.menu-trigger--close').trigger('click'); }, 2000);
    });
    $('#MMenu').on('click', function(){
        $('.menu-trigger').trigger('click');
        setTimeout(function(){ $('#M_mujer').trigger('click');;$('.menu-trigger--close').trigger('click'); }, 2000);
    });
    $('#NOMenu').on('click', function(){
        $('.menu-trigger').trigger('click');
        setTimeout(function(){ $('#M_niño').trigger('click');;$('.menu-trigger--close').trigger('click'); }, 2000);
    });
    $('#NAMenu').on('click', function(){
        $('.menu-trigger').trigger('click');
        setTimeout(function(){ $('#M_niña').trigger('click');;$('.menu-trigger--close').trigger('click'); }, 2000);
    });
});
